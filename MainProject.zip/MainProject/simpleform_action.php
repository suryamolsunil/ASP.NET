<?php
$con=@mysqli_connect("localhost","root","") or die('unable to connect db');
@mysqli_select_db($con,"Sample") or die('could not select db');
if(isset) 
	$sname=$_POST['name'];
	$sage=$_POST['age'];
	$sphone=$_POST['phone'];
	$adrs=$_POST['adrs'];
   $sql="insert into sample1(sname,sage,sphone,adrs) Values('$sname',$sage,'$sphone','$adrs')";
$result=mysqli_query($con,$sql);
 header("location:index.php");
?>



