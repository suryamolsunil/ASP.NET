<html>
<head>
<title>Simple Form</title>
<body>
<center>
<form name="simpleform" method="post" width="50px" height="50px" action="simpleform_action.php">
<table bgcolor="blue"><tr>
<td>Name</td>
<td><input type="text" name="name" required></td></tr>

<tr>
<td>Age</td>
<td><input type="text" name="age" required></td></tr>


<tr>
<td>Address</td>
<td> <textarea name="adrs" required></textarea></td></tr>

<tr>
<td>Phone</td>
<td><input type="text" name="phone" required></td></tr>

<tr>
<td><center>&nbsp&nbsp&nbsp&nbsp&nbsp <input type="submit" name="submit"  value="Add" required></center></td>
<td>&nbsp&nbsp&nbsp&nbsp&nbsp <input type="submit" name="update"  value="Update" required></td></tr>
</table>
</form>
</center>
</body>
</html>





